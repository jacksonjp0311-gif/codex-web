﻿# pre-commit.ps1

# Go to repo root
$repo = (git rev-parse --show-toplevel).Trim()
Set-Location $repo

# 1) Clean ledger
Write-Host "🔄 Cleaning ledger..." -ForegroundColor Cyan
& .\Load-Ledger.ps1
if ($LASTEXITCODE -ne 0) { exit 1 }

# 2) Snapshot
$ts = Get-Date -Format "yyyyMMdd-HHmmss"
$sDir = Join-Path $repo 'snapshots'
if (-not (Test-Path $sDir)) { New-Item -ItemType Directory -Path $sDir | Out-Null }
Copy-Item codex_ledger.json (Join-Path $sDir "codex_ledger.$ts.json") -Force
Write-Host "📸 Snapshot saved: snapshots\codex_ledger.$ts.json" -ForegroundColor Green

# 3) Pester tests
Write-Host "🧪 Running Pester tests..." -ForegroundColor Cyan
Import-Module Pester -ErrorAction SilentlyContinue
Invoke-Pester -Script (Join-Path $repo 'tests\Codex.Ledger.Tests.ps1') -PassThru | Out-Host
if ($LASTEXITCODE -ne 0) { exit 1 }

# 4) Copilot handshake (optional)
if (Get-Command copilot-cli -ErrorAction SilentlyContinue) {
  Write-Host "🤖 Running Copilot handshake..." -ForegroundColor Cyan
  $payload = @{
    request = @{
      script = Get-Content (Join-Path $repo 'Load-Ledger.ps1') -Raw
      ledger = Get-Content (Join-Path $repo 'codex_ledger.json') -Raw
    }
  }
  $payload | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $repo 'handshake.json')
  copilot-cli complete --input handshake.json --output suggestion.json
  Write-Host "💡 Copilot suggestion:" -ForegroundColor Yellow
  Get-Content suggestion.json | Out-Host
} else {
  Write-Host "⚠️  Copilot CLI not found; skipping handshake" -ForegroundColor DarkYellow
}

exit 0